package com.koor.hello;

import java.util.Date;
import java.io.*;
import java.nio.file.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub  
		String login = request.getParameter("txtLogin");
		String password = request.getParameter("txtPassword");
		if (login == null) login = "";
		if (password==null) password = "";
		System.out.println(login + "/"+password);
		response.setContentType("text/html");
		try (PrintWriter out = response.getWriter()){
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("		<head>");
			out.println("			<title>veuillez vous identifer</title>");
			out.println("			<link rel = 'stylesheet' type = 'text/css' href = 'style.css'/>");
			out.println("		</head>");
			out.println("		<body>");
			out.println("			<h1>veuillez vous identifer je test la</h1>");
			out.println("			<h2>"+ new Date() +"</h2>");
			out.println("			<form method='post' action = 'login'>");
			out.println("				Login : <input name = 'txtLogin' type='text' value = '"+login+"'/> </br>");
			out.println("				Password : <input name = 'txtPassword' type = 'password' value = '"+password+"'/> <br/>");
			out.println("				<input name = 'btnConnect' type = 'submit'/></br>");
			out.println("			</form>");
			out.println("		</body>");
			out.println("</html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String login = request.getParameter("txtLogin");
		String password = request.getParameter("txtPassword");
		int i;
		String line = new String();
		FileReader file = new FileReader("/Users/pierre-richardpascal/eclipse-workspace/helloworld/src/main/java/com/koor/hello/.htpasswd");
		BufferedReader buffer = new BufferedReader(file);
		Path fileLine = Paths.get("/Users/pierre-richardpascal/eclipse-workspace/helloworld/src/main/java/com/koor/hello/.htpasswd");
		long count = Files.lines(fileLine).count();
		final String sep = ":";

		for (i = 0; i <= count; i++) {

			line = buffer.readLine();
			if (line != null) {
				String tab[] = line.split(sep);
				if (login.equals(tab[0])){
					if (password.equals(tab[1])){
						FileReader ficheagent = new FileReader("/Users/pierre-richardpascal/eclipse-workspace/helloworld/src/main/java/com/koor/hello/FicheAgent/" + login +".txt");
		                BufferedReader bufferagent = new BufferedReader(ficheagent);
		                String lineAgent;
		                String nom = null;
		                String prenom = null;
		                String poste = null;
		                String equipement = "<p>";
		                int CptLigne = 0;
		                String repertoiire = null;
		                File dir  = new File("/Users/pierre-richardpascal/eclipse-workspace/helloworld/src");
		      		  File[] liste = dir.listFiles();
		      		  for(File item : liste){
		      			  if(item.isFile())
		      			  { 
		      				repertoiire =repertoiire +"Nom du fichier: "+request.getContextPath()+"/"+ item.getName()+"<br>"; 
		      			  } 
		      			  else if(item.isDirectory())
		      			  {
		      				repertoiire = "Nom du répertoire: "+request.getContextPath()+"/"+ item.getName()+"<br>"; 
		      			  } 
		      		  }
		                for (i = 1; i < 15; i++) {
		                    // Si le numéro de la ligne = 4 récupérer la ligne car c'est la qu'on obtient le mdp
		                	lineAgent = bufferagent.readLine();
		                	if (lineAgent != null) {
		                		CptLigne ++;
		                	}
		                    if (i == 1){
		                        nom = lineAgent;
		                    }
		                    if (i == 2){
		                        prenom = lineAgent;
		                    }
		                    if (i == 3){
		                        poste = lineAgent;
		                    }
		                    if (i>4) {
		                    	if(i <= CptLigne) {
		                    		equipement = equipement +"</p><p>"+ lineAgent;
		                    		
		                    	}
		                    }
		                    
		                  }
		                System.out.println(".."+request.getContextPath());
						PrintWriter out = response.getWriter();
						out.println("<!DOCTYPE html>");
						out.println("<html>");
						out.println("		<head>");
						out.println("			<title>Profil</title>");
						out.println("			<link rel = 'stylesheet' type = 'text/css' href = 'style.css'/>");
						out.println("		</head>");
						out.println("		<body>");
						out.println("			<h1>Bonjour, "+nom +" "+ prenom+" les informations de votre journée.</h1>");
						out.println("<p>"+repertoiire+"</p>");
						out.println("<img src = '/src/main/java/com/kor/hello/picsagent/"+login+".jpg'>");
						out.println("<p>Vous occuperez le poste de : "+ poste +" </p>");
						out.println(equipement);
						out.println("		</body>");
						out.println("</html>");
						System.out.println("Connexion réussi !");

					}
				}


			}
			// TODO Auto-generated method stub
		}

	}
}
